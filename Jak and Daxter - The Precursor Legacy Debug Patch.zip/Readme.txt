Use with:

Redump
Jak and Daxter - The Precursor Legacy (USA)
RAHash: c204101c3926d436efd36b81846d32c6